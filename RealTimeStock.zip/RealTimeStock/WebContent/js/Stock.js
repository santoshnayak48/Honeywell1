class Stock {
	constructor(name, curPrice){
		this.name = name;
		this.curPrice = curPrice;
		this.getLastWeekPrice = function(){
			var lastWeekPrice = new Array();
			for(var i=1;i<=7;i++){
				lastWeekPrice.push(i*curPrice);
			}
			return lastWeekPrice;
		};
	}
	
}